# NPS Dashboard — Reliance Digital

A self-serve NPS reporting utility. Drop in three CSV exports and get a full interactive dashboard with zone analysis, vendor outliers, and PDF export.

---

## What it does

- Upload Installation, Repair and Service CSV files from your CX platform
- Auto-calculates NPS using the standard %Promoters − %Detractors formula
- Shows scorecards, zone breakdown chart, vendor top/bottom tables, issue frequency chart
- Export to PDF via browser print
- All processing is 100% in-browser — no data leaves the user's machine

---

## Deploy to Vercel in 5 minutes

### Step 1 — Push code to GitHub

1. Go to https://github.com and create a new repository (e.g. `nps-dashboard`)
2. On your machine, open Terminal and run:

```bash
cd nps-app
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nps-dashboard.git
git push -u origin main
```

### Step 2 — Deploy on Vercel

1. Go to https://vercel.com and sign in with GitHub
2. Click **"Add New Project"**
3. Select your `nps-dashboard` repository
4. Vercel auto-detects Vite — just click **"Deploy"**
5. Done. Your URL will be: `https://nps-dashboard.vercel.app`

### Step 3 — Share the link

Send the Vercel URL to your team. Anyone with the link can:
- Upload their CSV files
- View the full dashboard instantly
- Export to PDF

---

## Run locally (for development)

```bash
cd nps-app
npm install
npm run dev
```

Open http://localhost:5173

---

## File structure

```
nps-app/
├── index.html              # Entry point
├── vite.config.js          # Build config
├── vercel.json             # Vercel deployment config
├── package.json
└── src/
    ├── main.jsx            # React entry
    ├── App.jsx             # Upload screen
    ├── utils/
    │   └── nps.js          # CSV parsing + NPS calculation logic
    └── components/
        └── Dashboard.jsx   # Full dashboard UI
```

---

## CSV format expected

The tool expects CSV files exported directly from your CX platform (Medallia / Qualtrics / ResQ).
Required columns:
- `Primary Question: How likely are you to recommend Reliance ResQ to your friend`
- `Group Zones`
- `Touchpoint name`
- Installation CSV also needs delivery and installation sub-rating columns

The first row is treated as a title row and skipped. The second row is used as column headers.

---

## Customisation

| What to change | Where |
|---|---|
| Brand name / logo | `src/App.jsx` — top header section |
| Colour scheme | `C` constant in `App.jsx` and `Dashboard.jsx` |
| Minimum vendor responses (default 10) | `minN` param in `nps.js` → `vendorOutliers()` |
| Zone order in chart | `ZONE_ORDER` array in `Dashboard.jsx` |
| Number of vendors shown | `.slice(0, 5)` in `Dashboard.jsx` vendor tables |

---

## Tech stack

- React 18
- Vite (build tool)
- Chart.js + react-chartjs-2 (charts)
- PapaParse (CSV parsing)
- Vercel (hosting — free tier works fine)

No backend. No database. No API keys needed.

---

Highly Confidential — Management Use Only
