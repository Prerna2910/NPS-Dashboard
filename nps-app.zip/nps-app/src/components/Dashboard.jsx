import { useRef } from 'react'
import { Bar, Doughnut } from 'react-chartjs-2'
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  ArcElement, Tooltip, Legend,
} from 'chart.js'

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend)

const C = {
  navy:'#0F2044', green:'#1D9E75', greenBg:'#EAF3DE', greenT:'#27500A',
  amber:'#E07B00', amberBg:'#FAEEDA', amberT:'#633806',
  red:'#D63B3B',  redBg:'#FCEBEB',   redT:'#791F1F',
  blue:'#378ADD', teal:'#028090',
  border:'#DEE4EE', off:'#F4F7FB', sub:'#5A6E85',
}

const ZONE_ORDER = ['EAST','SOUTH-3','SOUTH-1','SOUTH-2','NORTH-2','CENTRAL','WEST','NORTH-1']

function npsColor(n) {
  if (n === null || n === undefined) return C.sub
  return n >= 60 ? C.green : n >= 20 ? C.amber : C.red
}
function npsBg(n) {
  if (n === null || n === undefined) return C.off
  return n >= 60 ? C.greenBg : n >= 20 ? C.amberBg : C.redBg
}

function ScoreCard({ label, nps, total, pPct, color }) {
  return (
    <div style={{ background:'#fff', border:`1px solid ${C.border}`, borderRadius:12, padding:'20px 18px', textAlign:'center' }}>
      <div style={{ fontSize:12, color:C.sub, marginBottom:8 }}>{label}</div>
      <div style={{ fontSize:40, fontWeight:500, color: color || npsColor(nps), lineHeight:1 }}>
        {nps !== null ? `+${nps}` : '—'}
      </div>
      <div style={{ fontSize:11, color:C.sub, marginTop:8 }}>
        {total?.toLocaleString()} responses · {pPct}% promoters
      </div>
    </div>
  )
}

function NPSBreakdown({ data, title, color }) {
  if (!data) return null
  const { nps, promoters, passives, detractors, total, pPct, paPct, dPct } = data
  const sign = nps >= 0 ? '+' : ''
  return (
    <div style={{ background:'#fff', border:`1px solid ${C.border}`, borderRadius:12, overflow:'hidden', marginBottom:16 }}>
      <div style={{ background: color === C.amber ? '#FCF0DC' : '#D6F0EB', padding:'12px 18px', borderBottom:`1px solid ${C.border}` }}>
        <span style={{ fontWeight:500, fontSize:14, color: color === C.amber ? '#7A4F0A' : '#1D6B57' }}>{title}</span>
      </div>
      <div style={{ padding:'16px 18px', textAlign:'center', background:'#EAF7F3', borderBottom:`1px solid ${C.border}` }}>
        <div style={{ fontSize:48, fontWeight:500, color: npsColor(nps) }}>{sign}{nps}</div>
        <div style={{ fontSize:12, color:C.sub }}>NPS Score</div>
      </div>
      <div style={{ height:8, display:'flex' }}>
        <div style={{ width:`${pPct}%`,  background:C.green }} />
        <div style={{ width:`${paPct}%`, background:'#8A9BB0' }} />
        <div style={{ width:`${dPct}%`,  background:C.red }} />
      </div>
      {[
        { label:'Promoters (9–10)', val:promoters, pct:pPct,  bg:C.greenBg, fc:C.greenT },
        { label:'Passives (7–8)',   val:passives,  pct:paPct, bg:'#fff',     fc:C.sub },
        { label:'Detractors (0–6)', val:detractors,pct:dPct,  bg:C.redBg,   fc:C.redT },
      ].map(r => (
        <div key={r.label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 18px', background:r.bg, borderTop:`0.5px solid ${C.border}` }}>
          <span style={{ fontSize:13, color:r.fc }}>{r.label}</span>
          <div style={{ display:'flex', gap:16 }}>
            <span style={{ fontSize:13, fontWeight:500, color:r.fc }}>{r.val.toLocaleString()}</span>
            <span style={{ fontSize:13, color:C.sub, minWidth:34 }}>{r.pct}%</span>
          </div>
        </div>
      ))}
      <div style={{ padding:'8px 18px', borderTop:`0.5px solid ${C.border}`, display:'flex', justifyContent:'space-between' }}>
        <span style={{ fontSize:12, color:C.sub }}>Total responses</span>
        <span style={{ fontSize:12, fontWeight:500 }}>{total.toLocaleString()}</span>
      </div>
    </div>
  )
}

function ZoneChart({ instData, repairData, serviceData }) {
  const delZ  = instData?.byZone?.delivery || {}
  const insZ  = instData?.byZone?.installation || {}
  const repZ  = repairData?.byZone?.repair || {}
  const svcZ  = serviceData?.byZone?.service || {}

  const zones = ZONE_ORDER.filter(z => delZ[z] !== undefined || repZ[z] !== undefined)

  return (
    <div style={{ background:'#fff', border:`1px solid ${C.border}`, borderRadius:12, padding:20 }}>
      <h3 style={{ fontSize:14, fontWeight:500, marginBottom:16, color:C.navy }}>All 4 touchpoints by zone</h3>
      <Bar
        data={{
          labels: zones,
          datasets: [
            { label:'Delivery',     data: zones.map(z => delZ[z] ?? null),  backgroundColor: C.blue,  borderRadius: 3 },
            { label:'Installation', data: zones.map(z => insZ[z] ?? null),  backgroundColor: C.green, borderRadius: 3 },
            { label:'Repair',       data: zones.map(z => repZ[z] ?? null),  backgroundColor: C.teal,  borderRadius: 3 },
            { label:'Service',      data: zones.map(z => svcZ[z] ?? null),  backgroundColor: C.amber, borderRadius: 3 },
          ]
        }}
        options={{
          responsive: true,
          plugins: { legend: { position:'bottom', labels:{ boxWidth:12, font:{ size:11 } } } },
          scales: {
            x: { grid:{ display:false }, ticks:{ font:{ size:11 } } },
            y: { ticks:{ font:{ size:11 }, callback: v => (v >= 0 ? '+':'')+v }, grid:{ color:'#EEEEEE' } }
          }
        }}
      />
    </div>
  )
}

function VendorTable({ title, vendors, isGood, color }) {
  return (
    <div style={{ background:'#fff', border:`1px solid ${C.border}`, borderRadius:12, overflow:'hidden' }}>
      <div style={{ background: isGood ? C.greenBg : C.redBg, padding:'10px 16px', borderBottom:`1px solid ${C.border}` }}>
        <span style={{ fontSize:13, fontWeight:500, color: isGood ? C.greenT : C.redT }}>{title}</span>
      </div>
      <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
        <thead>
          <tr style={{ background:C.navy }}>
            {['Vendor Name','Zone','n','NPS'].map(h => (
              <th key={h} style={{ padding:'8px 12px', color:'#fff', textAlign: h === 'Vendor Name' ? 'left' : 'center', fontWeight:500 }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {vendors.slice(0, 5).map((v, i) => (
            <tr key={v.vendor} style={{ background: i % 2 === 0 ? '#fff' : C.off }}>
              <td style={{ padding:'8px 12px', color:'#1E2D40' }}>{v.vendor}</td>
              <td style={{ padding:'8px 12px', textAlign:'center' }}>
                <span style={{ background: v.nps < 0 ? C.redBg : C.greenBg, color: v.nps < 0 ? C.redT : C.greenT, padding:'2px 8px', borderRadius:10, fontSize:11, fontWeight:500 }}>
                  {v.zone}
                </span>
              </td>
              <td style={{ padding:'8px 12px', textAlign:'center', color:C.sub }}>{v.n}</td>
              <td style={{ padding:'8px 12px', textAlign:'center' }}>
                <span style={{ background: npsBg(v.nps), color: npsColor(v.nps), padding:'2px 10px', borderRadius:10, fontSize:12, fontWeight:500 }}>
                  {v.nps >= 0 ? '+':''}{v.nps}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function IssueChart({ issues }) {
  if (!issues?.length) return null
  const maxN = Math.max(...issues.map(i => i.count))
  return (
    <div style={{ background:'#fff', border:`1px solid ${C.border}`, borderRadius:12, padding:20 }}>
      <h3 style={{ fontSize:14, fontWeight:500, marginBottom:16, color:C.navy }}>Repair detractor issues</h3>
      {issues.map(({ label, count }) => (
        <div key={label} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
          <div style={{ fontSize:12, color:'#1E2D40', width:220, flexShrink:0 }}>{label}</div>
          <div style={{ flex:1, background:C.off, borderRadius:4, height:16, overflow:'hidden' }}>
            <div style={{ width:`${count/maxN*100}%`, height:'100%', background: count >= maxN*0.7 ? C.red : count >= maxN*0.4 ? C.amber : C.blue, borderRadius:4 }} />
          </div>
          <div style={{ fontSize:12, fontWeight:500, color:'#1E2D40', minWidth:32 }}>{count}</div>
        </div>
      ))}
    </div>
  )
}

function exportPDF() {
  window.print()
}

export default function Dashboard({ data, onReset }) {
  const { installation, repair, service, uploadedAt } = data
  const repVendors = repair?.vendorNPS || []
  const svcVendors = service?.vendorNPS || []

  return (
    <div style={{ minHeight:'100vh', background:C.off, padding:24 }}>
      <style>{`@media print { .no-print { display:none!important; } body { background:#fff; } }`}</style>

      <div style={{ maxWidth:1100, margin:'0 auto' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
          <div>
            <h1 style={{ fontSize:24, fontWeight:500, color:C.navy }}>NPS Performance Dashboard</h1>
            <p style={{ fontSize:13, color:C.sub, marginTop:2 }}>Reliance Digital · Generated {uploadedAt}</p>
          </div>
          <div style={{ display:'flex', gap:10 }} className="no-print">
            <button onClick={exportPDF} style={{ padding:'8px 18px', borderRadius:8, border:`1px solid ${C.border}`, background:'#fff', cursor:'pointer', fontSize:13, fontWeight:500 }}>
              Export PDF
            </button>
            <button onClick={onReset} style={{ padding:'8px 18px', borderRadius:8, border:`1px solid ${C.border}`, background:C.navy, color:'#fff', cursor:'pointer', fontSize:13, fontWeight:500 }}>
              Upload new files
            </button>
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:24 }}>
          <ScoreCard label="Delivery NPS"     nps={installation?.delivery?.nps}     total={installation?.delivery?.total}     pPct={installation?.delivery?.pPct}     color={C.blue} />
          <ScoreCard label="Installation NPS" nps={installation?.installation?.nps} total={installation?.installation?.total} pPct={installation?.installation?.pPct} color={C.green} />
          <ScoreCard label="Repair NPS"       nps={repair?.primary?.nps}            total={repair?.primary?.total}            pPct={repair?.primary?.pPct}            color={C.amber} />
          <ScoreCard label="Service NPS"      nps={service?.primary?.nps}           total={service?.primary?.total}           pPct={service?.primary?.pPct}           color={C.amber} />
        </div>

        <div style={{ marginBottom:24 }}>
          <ZoneChart instData={installation} repairData={repair} serviceData={service} />
        </div>

        <h2 style={{ fontSize:16, fontWeight:500, color:C.navy, marginBottom:16 }}>Detailed scorecards</h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:24 }}>
          <NPSBreakdown data={installation?.primary}      title="Installation"  color={C.green} />
          <NPSBreakdown data={repair?.primary}            title="Repair"        color={C.amber} />
          <NPSBreakdown data={service?.primary}           title="Service"       color={C.amber} />
        </div>

        <h2 style={{ fontSize:16, fontWeight:500, color:C.navy, marginBottom:16 }}>Vendor outliers — Repair</h2>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:24 }}>
          <VendorTable title="Bottom 5 vendors" vendors={repVendors.slice(0, 5)}  isGood={false} />
          <VendorTable title="Top 5 vendors"    vendors={[...repVendors].reverse().slice(0, 5)} isGood={true} />
        </div>

        <h2 style={{ fontSize:16, fontWeight:500, color:C.navy, marginBottom:16 }}>Vendor outliers — Service</h2>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:24 }}>
          <VendorTable title="Bottom 5 vendors" vendors={svcVendors.slice(0, 5)}  isGood={false} />
          <VendorTable title="Top 5 vendors"    vendors={[...svcVendors].reverse().slice(0, 5)} isGood={true} />
        </div>

        <IssueChart issues={repair?.issues} />

        <p style={{ textAlign:'center', fontSize:11, color:'#A0B0C4', marginTop:32 }}>
          Data processed in-browser · Nothing sent to any server · Highly Confidential — Management Review
        </p>
      </div>
    </div>
  )
}
