import Papa from 'papaparse'

const PRIMARY_Q = 'Primary Question: How likely are you to recommend Reliance ResQ to your friend'
const DELIVERY_Q = 'Please rate your Delivery Experience on a scale of 0 to 10, 10 being the highest.'
const INSTALL_Q = 'Please rate your installation experience on a scale of 0 to 10, 10 being the highest.'

export function parseCSV(file) {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: false,
      skipEmptyLines: true,
      complete: (results) => {
        const lines = results.data
        // skip first title row, use second as header
        const headers = lines[1]
        const rows = lines.slice(2).map(row => {
          const obj = {}
          headers.forEach((h, i) => { obj[h] = row[i] || '' })
          return obj
        })
        resolve(rows)
      },
      error: reject
    })
  })
}

function extractScore(val) {
  if (!val || !val.trim()) return null
  const m = val.match(/\((\d+)\)/)
  if (m) return parseInt(m[1])
  const n = parseFloat(val.trim())
  return isNaN(n) ? null : Math.round(n)
}

function calcNPS(scores) {
  const valid = scores.filter(s => s !== null)
  if (!valid.length) return null
  const p  = valid.filter(s => s >= 9).length
  const pa = valid.filter(s => s >= 7 && s <= 8).length
  const d  = valid.filter(s => s <= 6).length
  const t  = valid.length
  return {
    nps: Math.round((p - d) / t * 100),
    promoters: p, passives: pa, detractors: d, total: t,
    pPct: Math.round(p / t * 100),
    paPct: Math.round(pa / t * 100),
    dPct: Math.round(d / t * 100),
  }
}

export function processInstallation(rows) {
  const primaryScores  = rows.map(r => extractScore(r[PRIMARY_Q]))
  const deliveryScores = rows.map(r => extractScore(r[DELIVERY_Q]))
  const installScores  = rows.map(r => extractScore(r[INSTALL_Q]))
  return {
    primary:      calcNPS(primaryScores),
    delivery:     calcNPS(deliveryScores),
    installation: calcNPS(installScores),
    byZone: {
      delivery:     zoneNPS(rows, DELIVERY_Q),
      installation: zoneNPS(rows, INSTALL_Q),
    },
    vendorNPS: vendorOutliers(rows, PRIMARY_Q),
  }
}

export function processRepair(rows) {
  const scores = rows.map(r => extractScore(r[PRIMARY_Q]))
  return {
    primary: calcNPS(scores),
    byZone:  { repair: zoneNPS(rows, PRIMARY_Q) },
    vendorNPS: vendorOutliers(rows, PRIMARY_Q),
    issues: extractIssues(rows),
  }
}

export function processService(rows) {
  const scores = rows.map(r => extractScore(r[PRIMARY_Q]))
  return {
    primary: calcNPS(scores),
    byZone:  { service: zoneNPS(rows, PRIMARY_Q) },
    vendorNPS: vendorOutliers(rows, PRIMARY_Q),
  }
}

function zoneNPS(rows, col) {
  const map = {}
  rows.forEach(r => {
    const z = (r['Group Zones'] || '').trim()
    const s = extractScore(r[col])
    if (z && s !== null) {
      if (!map[z]) map[z] = []
      map[z].push(s)
    }
  })
  const result = {}
  Object.entries(map).forEach(([z, scores]) => {
    const p = scores.filter(s => s >= 9).length
    const d = scores.filter(s => s <= 6).length
    result[z] = Math.round((p - d) / scores.length * 100)
  })
  return result
}

function vendorOutliers(rows, col, minN = 10) {
  const map = {}
  rows.forEach(r => {
    const v = (r['Touchpoint name'] || '').trim()
    const z = (r['Group Zones'] || '').trim()
    const s = extractScore(r[col])
    if (v && s !== null) {
      if (!map[v]) map[v] = { scores: [], zone: z }
      map[v].scores.push(s)
    }
  })
  const result = []
  Object.entries(map).forEach(([vendor, { scores, zone }]) => {
    if (scores.length < minN) return
    const p = scores.filter(s => s >= 9).length
    const d = scores.filter(s => s <= 6).length
    result.push({
      vendor, zone, n: scores.length,
      nps: Math.round((p - d) / scores.length * 100),
    })
  })
  return result.sort((a, b) => a.nps - b.nps)
}

function extractIssues(rows) {
  const issueCols = Object.keys(rows[0] || {}).filter(k => k.includes('Oops') && k.includes('wrong'))
  const counts = {}
  rows.forEach(r => {
    const s = extractScore(r[PRIMARY_Q])
    if (s === null || s > 6) return
    issueCols.forEach(col => {
      const val = (r[col] || '').trim()
      if (val && val.toLowerCase() !== 'nan') {
        const label = col.match(/\(([^)]+)\)/)?.[1] || col
        counts[label] = (counts[label] || 0) + 1
      }
    })
  })
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 9)
    .map(([label, count]) => ({ label, count }))
}
