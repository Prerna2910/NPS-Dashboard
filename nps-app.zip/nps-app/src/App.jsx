import { useState, useCallback } from 'react'
import { parseCSV, processInstallation, processRepair, processService } from './utils/nps.js'
import Dashboard from './components/Dashboard.jsx'

const C = {
  navy: '#0F2044', green: '#1D9E75', amber: '#E07B00', red: '#D63B3B',
  greenBg: '#EAF3DE', amberBg: '#FAEEDA', redBg: '#FCEBEB',
  border: '#DEE4EE', off: '#F4F7FB',
}

function DropZone({ label, color, onFile, file }) {
  const [drag, setDrag] = useState(false)

  const handle = useCallback((f) => {
    if (f && f.name.endsWith('.csv')) onFile(f)
  }, [onFile])

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDrag(true) }}
      onDragLeave={() => setDrag(false)}
      onDrop={e => { e.preventDefault(); setDrag(false); handle(e.dataTransfer.files[0]) }}
      onClick={() => document.getElementById(`inp-${label}`).click()}
      style={{
        border: `2px dashed ${drag ? color : file ? color : C.border}`,
        borderRadius: 12, padding: '24px 16px', textAlign: 'center',
        cursor: 'pointer', background: file ? `${color}15` : '#fff',
        transition: 'all 0.15s',
      }}
    >
      <input id={`inp-${label}`} type="file" accept=".csv" style={{ display: 'none' }}
        onChange={e => handle(e.target.files[0])} />
      <div style={{ fontSize: 28, marginBottom: 8 }}>
        {file ? '✓' : '↑'}
      </div>
      <div style={{ fontWeight: 500, fontSize: 14, color: file ? color : '#1E2D40' }}>
        {file ? file.name : label}
      </div>
      <div style={{ fontSize: 12, color: '#8A9BB0', marginTop: 4 }}>
        {file ? `${(file.size / 1024).toFixed(1)} KB` : 'Drop CSV or click to browse'}
      </div>
    </div>
  )
}

export default function App() {
  const [files, setFiles] = useState({ installation: null, repair: null, service: null })
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const setFile = (key) => (f) => setFiles(prev => ({ ...prev, [key]: f }))

  async function analyse() {
    if (!files.installation || !files.repair || !files.service) {
      setError('Please upload all three CSV files to continue.')
      return
    }
    setLoading(true)
    setError(null)
    try {
      const [instRows, repairRows, serviceRows] = await Promise.all([
        parseCSV(files.installation),
        parseCSV(files.repair),
        parseCSV(files.service),
      ])
      setData({
        installation: processInstallation(instRows),
        repair:       processRepair(repairRows),
        service:      processService(serviceRows),
        uploadedAt:   new Date().toLocaleString('en-IN'),
      })
    } catch (e) {
      setError(`Error processing files: ${e.message}`)
    }
    setLoading(false)
  }

  if (data) return <Dashboard data={data} onReset={() => setData(null)} />

  return (
    <div style={{ minHeight: '100vh', background: C.off, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ maxWidth: 680, width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ display: 'inline-block', background: C.navy, color: '#fff', fontSize: 13, fontWeight: 500, padding: '4px 14px', borderRadius: 20, marginBottom: 16 }}>
            Reliance Digital · NPS Analytics
          </div>
          <h1 style={{ fontSize: 32, fontWeight: 500, color: C.navy, marginBottom: 8 }}>NPS Report Generator</h1>
          <p style={{ fontSize: 15, color: '#5A6E85', lineHeight: 1.6 }}>
            Upload your three survey CSV exports to generate a full NPS dashboard with zone analysis, vendor outliers, and downloadable report.
          </p>
        </div>

        <div style={{ background: '#fff', borderRadius: 16, border: `1px solid ${C.border}`, padding: 32, marginBottom: 16 }}>
          <h2 style={{ fontSize: 16, fontWeight: 500, color: C.navy, marginBottom: 20 }}>Upload survey files</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16, marginBottom: 24 }}>
            <DropZone label="Installation CSV" color={C.green} onFile={setFile('installation')} file={files.installation} />
            <DropZone label="Repair CSV"        color={C.amber} onFile={setFile('repair')}       file={files.repair} />
            <DropZone label="Service CSV"       color={C.amber} onFile={setFile('service')}      file={files.service} />
          </div>

          {error && (
            <div style={{ background: C.redBg, border: `1px solid ${C.red}`, borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: '#791F1F' }}>
              {error}
            </div>
          )}

          <button
            onClick={analyse}
            disabled={loading}
            style={{
              width: '100%', padding: '14px 0', borderRadius: 10, border: 'none',
              background: loading ? '#B5D4F4' : C.navy, color: '#fff',
              fontSize: 15, fontWeight: 500, cursor: loading ? 'not-allowed' : 'pointer',
            }}
          >
            {loading ? 'Analysing data...' : 'Generate NPS Dashboard →'}
          </button>
        </div>

        <div style={{ background: '#fff', borderRadius: 12, border: `1px solid ${C.border}`, padding: 20 }}>
          <h3 style={{ fontSize: 13, fontWeight: 500, color: '#5A6E85', marginBottom: 12 }}>What this tool generates</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {[
              ['NPS scores', 'Installation, Repair, Service + Delivery sub-question'],
              ['Zone breakdown', 'All 4 touchpoints across every zone'],
              ['Vendor outliers', 'Top & bottom 5 vendors for Repair and Service'],
              ['Detractor issues', 'Most common complaint categories from repair'],
              ['What went well', 'Auto-generated strengths by category'],
              ['Export to PDF', 'Download a formatted management report'],
            ].map(([title, desc]) => (
              <div key={title} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '8px 0', borderBottom: `0.5px solid ${C.border}` }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.green, marginTop: 6, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 12, fontWeight: 500, color: '#1E2D40' }}>{title}</div>
                  <div style={{ fontSize: 11, color: '#8A9BB0' }}>{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p style={{ textAlign: 'center', fontSize: 12, color: '#A0B0C4', marginTop: 20 }}>
          Data is processed entirely in your browser — nothing is sent to any server.
        </p>
      </div>
    </div>
  )
}
